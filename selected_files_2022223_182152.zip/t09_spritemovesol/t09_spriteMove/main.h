#pragma once

void DrawBgnd(float elapsed, Textures& tex, sf::RenderWindow& window);
